import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { canonicalJson, sha256 } from '../../../bench/catalog/load.ts';
import { inferenceDigest, apiRecordingSource } from '../../../bench/infer/recorded.ts';
import { openWorkDb } from '../../../bench/store/work-db.ts';
const work=openWorkDb();
const pairs=[...['luna','sonnet'].flatMap(p=>['', '-judge-luna','-judge-sonnet'].map(s=>[`quality-audited-${p}${s}`,`quality-finalized-${p}${s}`])),...['luna','sonnet'].map(p=>[`quality-repair-fixture-${p}`,`quality-repair-verified-${p}`])];
const lineage:any[]=[];
const run=work.startRun({kind:'recording-migration',config:{method:'verified-original-request-metadata',httpRequests:0},inputs:{pairs}});
try {
for(const [oldName,newName] of pairs){
 const oldRoot=join('data/runs/format',oldName!),newRoot=join('data/runs/format',newName!);
 if(existsSync(newRoot))throw Error('target exists '+newRoot);
 mkdirSync(newRoot,{recursive:true});
 for(const dir of ['recordings','repair-recordings','judge-recordings']){
  const oldDir=join(oldRoot,dir);if(!existsSync(oldDir))continue;
  mkdirSync(join(newRoot,dir),{recursive:true});
  for(const name of readdirSync(oldDir).filter(n=>n.endsWith('.json'))){
   const original=readFileSync(join(oldDir,name),'utf8'),record=JSON.parse(original),side=join(oldRoot,'api-provenance',dir,name);
   if(!existsSync(side)){writeFileSync(join(newRoot,dir,name),original,{flag:'wx',mode:0o600});lineage.push({oldName,newName,dir,name,kind:'unchanged-legacy',sha256:sha256(original)});continue;}
   const sideRaw=readFileSync(side,'utf8'),source=apiRecordingSource.parse(JSON.parse(sideRaw));
   const row=work.db.query<any,[string]>('SELECT config_json,inputs_json,status FROM runs WHERE run_id=?').get(source.runId);
   if(!row||row.status!=='completed')throw Error('not a completed API run');
   const config=JSON.parse(row.config_json),inputs=JSON.parse(row.inputs_json),entry=inputs.requests.find((r:any)=>r.name===name);
   const reqDir=config.phase==='compose'?'requests':config.phase+'-requests';
   const path=join('data/runs/format',config.session,reqDir,name),raw=readFileSync(path,'utf8'),request=JSON.parse(raw);
   if(!entry||sha256(raw)!==entry.sha256||source.promptDigest!==entry.promptDigest||request.promptDigest!==entry.promptDigest||source.outputDigest!==sha256(record.output))throw Error('immutable evidence mismatch '+path);
   const trial=work.db.query<any,[string]>('SELECT output_digest FROM trials WHERE trial_id=? AND status=\'completed\'').get(source.trialId);
   if(trial?.output_digest!==source.outputDigest)throw Error('trial output differs');
   const digest=inferenceDigest(request),schemaDigest=request.outputSchema===undefined?null:sha256(canonicalJson(request.outputSchema));
   const next={promptDigest:digest,output:record.output,evidence:'api'},nextSide={...source,promptDigest:digest,outputSchemaDigest:schemaDigest};
   mkdirSync(join(newRoot,'api-provenance',dir),{recursive:true});
   writeFileSync(join(newRoot,dir,name),canonicalJson(next),{flag:'wx',mode:0o600});
   writeFileSync(join(newRoot,'api-provenance',dir,name),canonicalJson(nextSide),{flag:'wx',mode:0o600});
   lineage.push({oldName,newName,dir,name,kind:'api-metadata-derived',sourceRunId:source.runId,sourceTrialId:source.trialId,originalRecordingSha256:sha256(original),originalSidecarSha256:sha256(sideRaw),originalRequestPath:path,originalRequestSha256:sha256(raw),oldPromptDigest:source.promptDigest,newPromptDigest:digest,outputSchemaDigest:schemaDigest,outputDigest:source.outputDigest});
  }
 }
 if(existsSync(join(oldRoot,'fault-injection.json')))writeFileSync(join(newRoot,'fault-injection.json'),readFileSync(join(oldRoot,'fault-injection.json')),{flag:'wx'});
}
writeFileSync('data/work/quality-improvement-2026-11-05/recording-migration.json',JSON.stringify({runId:run,httpRequests:0,originalFilesUnchanged:true,lineage},null,2),{flag:'wx'});
work.finishRun(run,'completed');console.log(JSON.stringify({runId:run,derived:lineage.filter(x=>x.kind==='api-metadata-derived').length,legacyUnchanged:lineage.filter(x=>x.kind==='unchanged-legacy').length,httpRequests:0}));
} catch(e){work.finishRun(run,'failed');throw e;}finally{work.close();}
