/** Prepare blinded plan judgements; this command performs no model calls. */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { parseArgs } from "node:util";
import { loadBenchCatalog, canonicalJson } from "../catalog/load.ts";
import { loadCases } from "../cases/cases.ts";
import { buildJudgeRequest, JUDGE_VERSION } from "../scoring/judge.ts";
import { inferenceDigest, RecordedInference } from "../infer/recorded.ts";
import { parseJsonFormat } from "../formats/json.ts";
import { installGuard } from "../mock/guard.ts";
import { checkDefinition } from "../../src/check.ts";

installGuard();
const { values } = parseArgs({
	options: {
		source: { type: "string" },
		session: { type: "string" },
		cases: { type: "string" },
		"native-schema": { type: "boolean" },
	},
});
if (
	!values.source ||
	!values.session ||
	![values.source, values.session].every((s) =>
		/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$/.test(s),
	)
)
	throw new Error(
		"judge preparation requires --source SESSION --session JUDGE_SESSION",
	);
const sources = RecordedInference.fromDirectory(
	join("data/runs/format", values.source, "recordings"),
);
const cases = new Map(loadCases(values.cases).map((c) => [c.id, c]));
const catalog = loadBenchCatalog();
const dir = join("data/runs/format", values.session, "judge-requests");
mkdirSync(dir, { recursive: true });
try {
	for (const [name, recording] of sources.files) {
		const id = name.replace(/--[^.]+\.json$/, "");
		const c = cases.get(id);
		if (!c) throw new Error(`missing source case: ${id}`);
		const parsed = parseJsonFormat(recording.output);
		const request = buildJudgeRequest({
			request: c.request,
			providedMaterials: c.providedMaterials,
			cards: catalog.cards,
			candidate: parsed.ok ? parsed.outcome : { raw: recording.output },
			...(parsed.ok && parsed.outcome.kind === "ready"
				? {
						structuralCheck: checkDefinition(
							parsed.outcome.definition,
							catalog.view,
							{ sourceRequest: c.request },
						),
					}
				: {}),
		});
		if (!values["native-schema"]) delete request.outputSchema;
		const target = join(dir, name);
		const content = canonicalJson({
			...request,
			promptDigest: inferenceDigest(request),
		});
		if (existsSync(target) && readFileSync(target, "utf8") !== content)
			throw new Error("judge session already has different requests");
		if (!existsSync(target))
			writeFileSync(target, content, { flag: "wx", mode: 0o600 });
	}
	console.log(
		JSON.stringify({
			session: values.session,
			prepared: sources.files.size,
			judgeVersion: JUDGE_VERSION,
		}),
	);
} finally {
	catalog.close();
}
